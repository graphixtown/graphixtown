import { 
  type Service, 
  type InsertService,
  type PortfolioItem,
  type InsertPortfolioItem,
  type SiteContent,
  type InsertSiteContent,
  type ContactSubmission,
  type InsertContactSubmission
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Services
  getServices(): Promise<Service[]>;
  getService(id: string): Promise<Service | undefined>;
  createService(service: InsertService): Promise<Service>;
  updateService(id: string, service: Partial<InsertService>): Promise<Service | undefined>;
  deleteService(id: string): Promise<boolean>;

  // Portfolio
  getPortfolioItems(): Promise<PortfolioItem[]>;
  getPortfolioItem(id: string): Promise<PortfolioItem | undefined>;
  getPortfolioItemsByCategory(category: string): Promise<PortfolioItem[]>;
  createPortfolioItem(item: InsertPortfolioItem): Promise<PortfolioItem>;
  updatePortfolioItem(id: string, item: Partial<InsertPortfolioItem>): Promise<PortfolioItem | undefined>;
  deletePortfolioItem(id: string): Promise<boolean>;

  // Site Content
  getSiteContent(section: string): Promise<SiteContent | undefined>;
  updateSiteContent(section: string, content: any): Promise<SiteContent>;

  // Contact Submissions
  getContactSubmissions(): Promise<ContactSubmission[]>;
  createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission>;
  updateContactSubmissionStatus(id: string, status: string): Promise<ContactSubmission | undefined>;
}

export class MemStorage implements IStorage {
  private services: Map<string, Service>;
  private portfolioItems: Map<string, PortfolioItem>;
  private siteContent: Map<string, SiteContent>;
  private contactSubmissions: Map<string, ContactSubmission>;

  constructor() {
    this.services = new Map();
    this.portfolioItems = new Map();
    this.siteContent = new Map();
    this.contactSubmissions = new Map();
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Default services
    const defaultServices: Service[] = [
      {
        id: "1",
        title: "Graphics Design",
        description: "Custom logos, branding, social media graphics, and visual identity design that makes your brand stand out.",
        icon: "palette",
        features: ["Logo Design", "Brand Identity", "Social Media Graphics"],
        price: "$299+",
        order: 1,
        createdAt: new Date(),
      },
      {
        id: "2",
        title: "Video Editing",
        description: "Professional video editing, color grading, motion graphics, and post-production services for all your needs.",
        icon: "video",
        features: ["Video Editing", "Color Grading", "Motion Graphics"],
        price: "$499+",
        order: 2,
        createdAt: new Date(),
      },
      {
        id: "3",
        title: "Motion Graphics",
        description: "Dynamic animations, explainer videos, and motion graphics that bring your content to life with engaging visuals.",
        icon: "magic",
        features: ["2D Animation", "Explainer Videos", "Logo Animation"],
        price: "$799+",
        order: 3,
        createdAt: new Date(),
      },
    ];

    defaultServices.forEach(service => {
      this.services.set(service.id, service);
    });

    // Default portfolio items
    const defaultPortfolioItems: PortfolioItem[] = [
      {
        id: "1",
        title: "Brand Identity Design",
        description: "Complete visual identity for tech startup",
        category: "graphics",
        imageUrl: "https://images.unsplash.com/photo-1561070791-2526d30994b5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        order: 1,
        featured: true,
        createdAt: new Date(),
      },
      {
        id: "2",
        title: "Corporate Video",
        description: "Professional promotional video editing",
        category: "video",
        imageUrl: "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        order: 2,
        featured: true,
        createdAt: new Date(),
      },
      {
        id: "3",
        title: "Social Media Graphics",
        description: "Engaging social media content design",
        category: "graphics",
        imageUrl: "https://images.unsplash.com/photo-1586953208448-b95a79798f07?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        order: 3,
        featured: false,
        createdAt: new Date(),
      },
      {
        id: "4",
        title: "Motion Graphics",
        description: "Dynamic animated logo design",
        category: "motion",
        imageUrl: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        order: 4,
        featured: false,
        createdAt: new Date(),
      },
      {
        id: "5",
        title: "Documentary Editing",
        description: "Professional documentary post-production",
        category: "video",
        imageUrl: "https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        order: 5,
        featured: false,
        createdAt: new Date(),
      },
      {
        id: "6",
        title: "UI/UX Design",
        description: "Modern interface design system",
        category: "graphics",
        imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        order: 6,
        featured: false,
        createdAt: new Date(),
      },
    ];

    defaultPortfolioItems.forEach(item => {
      this.portfolioItems.set(item.id, item);
    });

    // Default site content
    const defaultSiteContent = [
      {
        id: "hero",
        section: "hero",
        content: {
          title: "Creative GFX & Video Solutions",
          subtitle: "Transform your ideas into stunning visual experiences with our professional graphics design and video editing services.",
          backgroundImage: "https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"
        },
        updatedAt: new Date(),
      },
      {
        id: "about",
        section: "about",
        content: {
          title: "About GFX Town",
          description: "We're a team of passionate creatives dedicated to transforming your vision into stunning visual experiences. With years of expertise in graphics design and video editing, we deliver results that exceed expectations.",
          stats: {
            projectsCompleted: "500+",
            happyClients: "250+",
            yearsExperience: "8+",
            awards: "15+"
          }
        },
        updatedAt: new Date(),
      },
      {
        id: "contact",
        section: "contact",
        content: {
          address: "123 Creative Street, Design City, DC 12345",
          phone: "+1 (555) 123-4567",
          email: "hello@gfxtown.com"
        },
        updatedAt: new Date(),
      },
    ];

    defaultSiteContent.forEach(content => {
      this.siteContent.set(content.section, content);
    });
  }

  // Services methods
  async getServices(): Promise<Service[]> {
    return Array.from(this.services.values()).sort((a, b) => a.order - b.order);
  }

  async getService(id: string): Promise<Service | undefined> {
    return this.services.get(id);
  }

  async createService(insertService: InsertService): Promise<Service> {
    const id = randomUUID();
    const service: Service = {
      id,
      title: insertService.title,
      description: insertService.description,
      icon: insertService.icon,
      features: insertService.features,
      price: insertService.price,
      order: insertService.order || 0,
      createdAt: new Date(),
    };
    this.services.set(id, service);
    return service;
  }

  async updateService(id: string, updates: Partial<InsertService>): Promise<Service | undefined> {
    const service = this.services.get(id);
    if (!service) return undefined;
    
    const updatedService: Service = { 
      id: service.id,
      title: updates.title !== undefined ? updates.title : service.title,
      description: updates.description !== undefined ? updates.description : service.description,
      icon: updates.icon !== undefined ? updates.icon : service.icon,
      features: updates.features !== undefined ? updates.features : service.features,
      price: updates.price !== undefined ? updates.price : service.price,
      order: updates.order !== undefined ? updates.order : service.order,
      createdAt: service.createdAt,
    };
    this.services.set(id, updatedService);
    return updatedService;
  }

  async deleteService(id: string): Promise<boolean> {
    return this.services.delete(id);
  }

  // Portfolio methods
  async getPortfolioItems(): Promise<PortfolioItem[]> {
    return Array.from(this.portfolioItems.values()).sort((a, b) => a.order - b.order);
  }

  async getPortfolioItem(id: string): Promise<PortfolioItem | undefined> {
    return this.portfolioItems.get(id);
  }

  async getPortfolioItemsByCategory(category: string): Promise<PortfolioItem[]> {
    return Array.from(this.portfolioItems.values())
      .filter(item => item.category === category)
      .sort((a, b) => a.order - b.order);
  }

  async createPortfolioItem(insertItem: InsertPortfolioItem): Promise<PortfolioItem> {
    const id = randomUUID();
    const item: PortfolioItem = {
      ...insertItem,
      id,
      order: insertItem.order || 0,
      featured: insertItem.featured || false,
      createdAt: new Date(),
    };
    this.portfolioItems.set(id, item);
    return item;
  }

  async updatePortfolioItem(id: string, updates: Partial<InsertPortfolioItem>): Promise<PortfolioItem | undefined> {
    const item = this.portfolioItems.get(id);
    if (!item) return undefined;
    
    const updatedItem = { ...item, ...updates };
    this.portfolioItems.set(id, updatedItem);
    return updatedItem;
  }

  async deletePortfolioItem(id: string): Promise<boolean> {
    return this.portfolioItems.delete(id);
  }

  // Site content methods
  async getSiteContent(section: string): Promise<SiteContent | undefined> {
    return this.siteContent.get(section);
  }

  async updateSiteContent(section: string, content: any): Promise<SiteContent> {
    const existing = this.siteContent.get(section);
    const siteContent: SiteContent = {
      id: existing?.id || randomUUID(),
      section,
      content,
      updatedAt: new Date(),
    };
    this.siteContent.set(section, siteContent);
    return siteContent;
  }

  // Contact submission methods
  async getContactSubmissions(): Promise<ContactSubmission[]> {
    return Array.from(this.contactSubmissions.values())
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }

  async createContactSubmission(insertSubmission: InsertContactSubmission): Promise<ContactSubmission> {
    const id = randomUUID();
    const submission: ContactSubmission = {
      ...insertSubmission,
      id,
      status: "new",
      createdAt: new Date(),
    };
    this.contactSubmissions.set(id, submission);
    return submission;
  }

  async updateContactSubmissionStatus(id: string, status: string): Promise<ContactSubmission | undefined> {
    const submission = this.contactSubmissions.get(id);
    if (!submission) return undefined;
    
    const updatedSubmission = { ...submission, status };
    this.contactSubmissions.set(id, updatedSubmission);
    return updatedSubmission;
  }
}

export const storage = new MemStorage();
