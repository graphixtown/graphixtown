import { Button } from "@/components/ui/button";
import { Edit, Image, Plus, Upload, Move, FormInput, Mail } from "lucide-react";

interface AdminAction {
  label: string;
  icon: string;
  action: () => void;
}

interface AdminControlsProps {
  actions: AdminAction[];
}

const iconMap = {
  edit: Edit,
  image: Image,
  plus: Plus,
  upload: Upload,
  move: Move,
  form: FormInput,
  mail: Mail,
};

export default function AdminControls({ actions }: AdminControlsProps) {
  return (
    <div className="admin-controls">
      {actions.map((action, index) => {
        const IconComponent = iconMap[action.icon as keyof typeof iconMap] || Edit;
        
        return (
          <Button
            key={index}
            size="sm"
            className="bg-primary text-white mr-2 mb-2"
            onClick={action.action}
          >
            <IconComponent className="w-4 h-4 mr-1" />
            {action.label}
          </Button>
        );
      })}
    </div>
  );
}
