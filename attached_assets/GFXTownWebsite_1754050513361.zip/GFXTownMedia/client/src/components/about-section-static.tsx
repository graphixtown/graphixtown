import { Button } from "@/components/ui/button";
import AdminControls from "@/components/admin-controls";

export default function AboutSectionStatic() {
  const scrollToContact = () => {
    const element = document.querySelector("#contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  // Static content - easily editable for GitHub Pages
  const content = {
    title: "About GFX Town",
    description: "We're a team of passionate creatives dedicated to transforming your vision into stunning visual experiences. With years of expertise in graphics design and video editing, we deliver results that exceed expectations.",
    stats: {
      projectsCompleted: "500+",
      happyClients: "250+",
      yearsExperience: "8+",
      awards: "15+"
    }
  };

  return (
    <section id="about" className="py-20 bg-[var(--dark-secondary)] customizable-section">
      <AdminControls
        actions={[
          { label: "Edit Content", icon: "edit", action: () => console.log("Edit about content in code") }
        ]}
      />
      
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold mb-6">{content.title}</h2>
            <p className="text-xl text-gray-400 mb-8">
              {content.description}
            </p>
            
            <div className="grid grid-cols-2 gap-8 mb-8">
              <div className="text-center">
                <div className="text-4xl font-bold text-primary mb-2">
                  {content.stats.projectsCompleted}
                </div>
                <div className="text-gray-400">Projects Completed</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-secondary mb-2">
                  {content.stats.happyClients}
                </div>
                <div className="text-gray-400">Happy Clients</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-accent mb-2">
                  {content.stats.yearsExperience}
                </div>
                <div className="text-gray-400">Years Experience</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-[var(--danger)] mb-2">
                  {content.stats.awards}
                </div>
                <div className="text-gray-400">Awards Won</div>
              </div>
            </div>
            
            <Button
              size="lg"
              className="bg-primary hover:bg-purple-600 transition-colors"
              onClick={scrollToContact}
            >
              Work With Us
            </Button>
          </div>
          
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Professional creative studio workspace with design equipment" 
              className="rounded-2xl shadow-2xl w-full" 
            />
            <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-gradient-to-r from-primary to-secondary rounded-2xl opacity-80" />
            <div className="absolute -top-8 -right-8 w-24 h-24 bg-gradient-to-r from-accent to-[var(--danger)] rounded-2xl opacity-60" />
          </div>
        </div>
      </div>
    </section>
  );
}