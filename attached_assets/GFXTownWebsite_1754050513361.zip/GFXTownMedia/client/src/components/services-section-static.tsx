import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Palette, Video, Wand2, Check } from "lucide-react";
import AdminControls from "@/components/admin-controls";

const iconMap = {
  palette: Palette,
  video: Video,
  magic: Wand2,
};

export default function ServicesSectionStatic() {
  // Static services data - easily editable for GitHub Pages
  const services = [
    {
      id: "1",
      title: "Graphics Design",
      description: "Custom logos, branding, social media graphics, and visual identity design that makes your brand stand out.",
      icon: "palette",
      features: ["Logo Design", "Brand Identity", "Social Media Graphics"],
      price: "$299+",
      order: 1,
    },
    {
      id: "2",
      title: "Video Editing",
      description: "Professional video editing, color grading, motion graphics, and post-production services for all your needs.",
      icon: "video",
      features: ["Video Editing", "Color Grading", "Motion Graphics"],
      price: "$499+",
      order: 2,
    },
    {
      id: "3",
      title: "Motion Graphics",
      description: "Dynamic animations, explainer videos, and motion graphics that bring your content to life with engaging visuals.",
      icon: "magic",
      features: ["2D Animation", "Explainer Videos", "Logo Animation"],
      price: "$799+",
      order: 3,
    },
  ];

  const scrollToContact = () => {
    const element = document.querySelector("#contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="services" className="py-20 bg-[var(--dark-secondary)] customizable-section">
      <AdminControls
        actions={[
          { label: "Edit Services", icon: "edit", action: () => console.log("Edit services in code") }
        ]}
      />
      
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Our Services</h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            From concept to completion, we deliver premium visual content that elevates your brand and engages your audience.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => {
            const IconComponent = iconMap[service.icon as keyof typeof iconMap] || Palette;
            
            return (
              <Card 
                key={service.id} 
                className="glass-morphism hover:transform hover:scale-105 transition-all duration-300 group border-gray-700"
              >
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-2xl flex items-center justify-center mb-6 group-hover:animate-pulse">
                    <IconComponent className="text-2xl text-white" size={24} />
                  </div>
                  <h3 className="text-2xl font-semibold mb-4">{service.title}</h3>
                  <p className="text-gray-400 mb-6">{service.description}</p>
                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm">
                        <Check className="text-primary mr-2" size={16} />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold">{service.price}</span>
                    <Button
                      className="bg-primary hover:bg-purple-600 transition-colors"
                      onClick={scrollToContact}
                    >
                      Get Quote
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}