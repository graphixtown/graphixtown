import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin, Phone, Mail, Facebook, Twitter, Instagram, Linkedin } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import AdminControls from "@/components/admin-controls";

// Simple contact form schema for static sites
const contactFormSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Please enter a valid email"),
  service: z.string().min(1, "Please select a service"),
  budget: z.string().min(1, "Please select a budget range"),
  description: z.string().min(10, "Please provide more details about your project"),
});

type ContactFormData = z.infer<typeof contactFormSchema>;

export default function ContactSectionStatic() {
  const { toast } = useToast();

  const form = useForm<ContactFormData>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      service: "",
      budget: "",
      description: "",
    },
  });

  const onSubmit = (data: ContactFormData) => {
    // Create email content
    const subject = `Project Inquiry - ${data.service}`;
    const body = `Hello GFX Town,

My name is ${data.firstName} ${data.lastName} and I'm interested in your ${data.service} services.

Contact Information:
- Email: ${data.email}
- Budget Range: ${data.budget}

Project Details:
${data.description}

Please get back to me at your earliest convenience.

Best regards,
${data.firstName} ${data.lastName}`;

    // Create mailto link
    const mailtoLink = `mailto:workforgraphixtown@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    
    // Open email client
    window.location.href = mailtoLink;

    toast({
      title: "Opening your email client...",
      description: "We'll respond to your inquiry within 24 hours.",
    });
    
    // Reset form after a short delay
    setTimeout(() => {
      form.reset();
    }, 1000);
  };

  // Static contact information
  const contactInfo = {
    address: "123 Creative Street, Design City, DC 12345",
    phone: "+1 (555) 123-4567",
    email: "workforgraphixtown@gmail.com"
  };

  return (
    <section id="contact" className="py-20 bg-[var(--dark)] customizable-section">
      <AdminControls
        actions={[
          { label: "Edit Info", icon: "edit", action: () => console.log("Edit contact info") },
          { label: "Email Setup", icon: "mail", action: () => console.log("Configure EmailJS") }
        ]}
      />
      
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Get In Touch</h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Ready to elevate your visual content? Let's discuss your project and bring your creative vision to life.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-16">
          <div>
            <div className="space-y-8">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center">
                  <MapPin className="text-white" size={20} />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-1">Our Location</h3>
                  <p className="text-gray-400">{contactInfo.address}</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-secondary rounded-lg flex items-center justify-center">
                  <Phone className="text-white" size={20} />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-1">Phone</h3>
                  <p className="text-gray-400">{contactInfo.phone}</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-accent rounded-lg flex items-center justify-center">
                  <Mail className="text-white" size={20} />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-1">Email</h3>
                  <p className="text-gray-400">{contactInfo.email}</p>
                </div>
              </div>
            </div>
            
            <div className="mt-12">
              <h3 className="text-2xl font-semibold mb-6">Follow Us</h3>
              <div className="flex space-x-4">
                <a href="#" className="w-12 h-12 bg-gray-700 hover:bg-primary rounded-lg flex items-center justify-center transition-colors">
                  <Facebook className="text-white" size={20} />
                </a>
                <a href="#" className="w-12 h-12 bg-gray-700 hover:bg-primary rounded-lg flex items-center justify-center transition-colors">
                  <Twitter className="text-white" size={20} />
                </a>
                <a href="#" className="w-12 h-12 bg-gray-700 hover:bg-primary rounded-lg flex items-center justify-center transition-colors">
                  <Instagram className="text-white" size={20} />
                </a>
                <a href="#" className="w-12 h-12 bg-gray-700 hover:bg-primary rounded-lg flex items-center justify-center transition-colors">
                  <Linkedin className="text-white" size={20} />
                </a>
              </div>
            </div>

            <div className="mt-12 p-6 bg-[var(--dark-secondary)] rounded-lg border border-gray-700">
              <h4 className="text-lg font-semibold mb-3 text-primary">📧 How Contact Works</h4>
              <ul className="text-gray-400 space-y-2 text-sm">
                <li>• Form opens your email client with pre-filled message</li>
                <li>• No backend server required - perfect for GitHub Pages</li>
                <li>• Works with any email app (Gmail, Outlook, Apple Mail)</li>
                <li>• Send directly to: {contactInfo.email}</li>
              </ul>
            </div>
          </div>
          
          <Card className="glass-morphism border-gray-700">
            <CardContent className="p-8">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>First Name</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="John" 
                              className="bg-gray-800 border-gray-600 focus:border-primary"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Last Name</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Doe" 
                              className="bg-gray-800 border-gray-600 focus:border-primary"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input 
                            type="email"
                            placeholder="john@example.com" 
                            className="bg-gray-800 border-gray-600 focus:border-primary"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="service"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Service Needed</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-gray-800 border-gray-600 focus:border-primary">
                              <SelectValue placeholder="Select a service" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="graphics">Graphics Design</SelectItem>
                            <SelectItem value="video">Video Editing</SelectItem>
                            <SelectItem value="motion">Motion Graphics</SelectItem>
                            <SelectItem value="consultation">Consultation</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="budget"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Project Budget</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-gray-800 border-gray-600 focus:border-primary">
                              <SelectValue placeholder="Select budget range" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="under-1k">Under $1,000</SelectItem>
                            <SelectItem value="1k-5k">$1,000 - $5,000</SelectItem>
                            <SelectItem value="5k-10k">$5,000 - $10,000</SelectItem>
                            <SelectItem value="10k-plus">$10,000+</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Project Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Tell us about your project..." 
                            className="bg-gray-800 border-gray-600 focus:border-primary h-32 resize-none"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    size="lg"
                    className="w-full bg-gradient-to-r from-primary to-secondary hover:from-purple-600 hover:to-primary transition-all transform hover:scale-105"
                  >
                    Open Email Client
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}