import { useState } from "react";
import { Button } from "@/components/ui/button";
import AdminControls from "@/components/admin-controls";

export default function PortfolioSectionStatic() {
  const [activeFilter, setActiveFilter] = useState("all");
  
  // Static portfolio data - easily editable for GitHub Pages
  const portfolioItems = [
    {
      id: "1",
      title: "Brand Identity Design",
      description: "Complete visual identity for tech startup",
      category: "graphics",
      imageUrl: "https://images.unsplash.com/photo-1561070791-2526d30994b5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      order: 1,
      featured: true,
    },
    {
      id: "2",
      title: "Corporate Video",
      description: "Professional promotional video editing",
      category: "video",
      imageUrl: "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      order: 2,
      featured: true,
    },
    {
      id: "3",
      title: "Social Media Graphics",
      description: "Engaging social media content design",
      category: "graphics",
      imageUrl: "https://images.unsplash.com/photo-1586953208448-b95a79798f07?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      order: 3,
      featured: false,
    },
    {
      id: "4",
      title: "Motion Graphics",
      description: "Dynamic animated logo design",
      category: "motion",
      imageUrl: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      order: 4,
      featured: false,
    },
    {
      id: "5",
      title: "Documentary Editing",
      description: "Professional documentary post-production",
      category: "video",
      imageUrl: "https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      order: 5,
      featured: false,
    },
    {
      id: "6",
      title: "UI/UX Design",
      description: "Modern interface design system",
      category: "graphics",
      imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      order: 6,
      featured: false,
    },
  ];

  const categories = [
    { key: "all", label: "All Work" },
    { key: "graphics", label: "Graphics" },
    { key: "video", label: "Video" },
    { key: "motion", label: "Motion" },
  ];

  const filteredItems = activeFilter === "all" 
    ? portfolioItems 
    : portfolioItems.filter(item => item.category === activeFilter);

  return (
    <section id="portfolio" className="py-20 bg-[var(--dark)] customizable-section">
      <AdminControls
        actions={[
          { label: "Edit Portfolio", icon: "edit", action: () => console.log("Edit portfolio items in code") },
          { label: "Add Images", icon: "upload", action: () => console.log("Upload new portfolio images") }
        ]}
      />
      
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Our Portfolio</h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto mb-8">
            Explore our latest projects and see how we've helped businesses transform their visual presence.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category) => (
              <Button
                key={category.key}
                variant={activeFilter === category.key ? "default" : "secondary"}
                className={`px-6 py-2 font-medium transition-colors ${
                  activeFilter === category.key 
                    ? "bg-primary text-white" 
                    : "bg-gray-700 hover:bg-primary text-white"
                }`}
                onClick={() => setActiveFilter(category.key)}
              >
                {category.label}
              </Button>
            ))}
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((item) => (
            <div key={item.id} className="group cursor-pointer">
              <div className="relative overflow-hidden rounded-2xl">
                <img 
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[var(--dark)]/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                    <p className="text-gray-300 text-sm">{item.description}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {filteredItems.length > 6 && (
          <div className="text-center mt-12">
            <Button
              size="lg"
              className="bg-gradient-to-r from-primary to-secondary hover:from-purple-600 hover:to-primary transition-all transform hover:scale-105"
            >
              Load More Projects
            </Button>
          </div>
        )}
      </div>
    </section>
  );
}