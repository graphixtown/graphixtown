import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Palette, Video, Wand2, Check } from "lucide-react";
import AdminControls from "@/components/admin-controls";
import type { Service } from "@shared/schema";

const iconMap = {
  palette: Palette,
  video: Video,
  magic: Wand2,
};

export default function ServicesSection() {
  const { data: services = [], isLoading } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  const scrollToContact = () => {
    const element = document.querySelector("#contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  if (isLoading) {
    return (
      <section className="py-20 bg-[var(--dark-secondary)]">
        <div className="container mx-auto px-6">
          <div className="text-center">Loading services...</div>
        </div>
      </section>
    );
  }

  return (
    <section id="services" className="py-20 bg-[var(--dark-secondary)] customizable-section">
      <AdminControls
        actions={[
          { label: "Add Service", icon: "plus", action: () => console.log("Add service") }
        ]}
      />
      
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Our Services</h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            From concept to completion, we deliver premium visual content that elevates your brand and engages your audience.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => {
            const IconComponent = iconMap[service.icon as keyof typeof iconMap] || Palette;
            
            return (
              <Card 
                key={service.id} 
                className="glass-morphism hover:transform hover:scale-105 transition-all duration-300 group border-gray-700"
              >
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-2xl flex items-center justify-center mb-6 group-hover:animate-pulse">
                    <IconComponent className="text-2xl text-white" size={24} />
                  </div>
                  <h3 className="text-2xl font-semibold mb-4">{service.title}</h3>
                  <p className="text-gray-400 mb-6">{service.description}</p>
                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm">
                        <Check className="text-primary mr-2" size={16} />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold">{service.price}</span>
                    <Button
                      className="bg-primary hover:bg-purple-600 transition-colors"
                      onClick={scrollToContact}
                    >
                      Get Quote
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
