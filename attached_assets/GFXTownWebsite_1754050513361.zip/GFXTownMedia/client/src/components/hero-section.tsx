import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import AdminControls from "@/components/admin-controls";

export default function HeroSection() {
  const { data: heroContent } = useQuery({
    queryKey: ["/api/content/hero"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const scrollToSection = (selector: string) => {
    const element = document.querySelector(selector);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const content = (heroContent as any)?.content || {
    title: "Creative GFX & Video Solutions",
    subtitle: "Transform your ideas into stunning visual experiences with our professional graphics design and video editing services.",
    backgroundImage: "https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"
  };

  return (
    <section id="home" className="customizable-section min-h-screen flex items-center relative overflow-hidden">
      <AdminControls
        actions={[
          { label: "Edit", icon: "edit", action: () => console.log("Edit hero content") },
          { label: "BG", icon: "image", action: () => console.log("Change background") }
        ]}
      />
      
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat" 
        style={{
          backgroundImage: `linear-gradient(rgba(15, 15, 35, 0.8), rgba(15, 15, 35, 0.8)), url('${content.backgroundImage}')`
        }}
      />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="animate-slide-up">
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              {content.title.split(" ").map((word: string, index: number) => 
                word === "GFX" ? (
                  <span key={index} className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                    {word}{" "}
                  </span>
                ) : (
                  <span key={index}>{word} </span>
                )
              )}
            </h1>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              {content.subtitle}
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="bg-gradient-to-r from-primary to-secondary hover:from-purple-600 hover:to-primary transition-all transform hover:scale-105"
                onClick={() => scrollToSection("#portfolio")}
              >
                View Our Work
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-primary hover:bg-primary transition-all"
                onClick={() => scrollToSection("#contact")}
              >
                Get Started
              </Button>
            </div>
          </div>
          
          <div className="relative animate-float">
            <img 
              src="https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Professional video editing workspace with multiple monitors" 
              className="rounded-2xl shadow-2xl w-full" 
            />
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-gradient-to-r from-accent to-[var(--danger)] rounded-2xl opacity-80" />
            <div className="absolute -top-6 -left-6 w-24 h-24 bg-gradient-to-r from-secondary to-primary rounded-2xl opacity-60" />
          </div>
        </div>
      </div>
    </section>
  );
}
