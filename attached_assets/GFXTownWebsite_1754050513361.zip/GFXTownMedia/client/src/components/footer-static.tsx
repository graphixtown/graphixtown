import { Play, Facebook, Twitter, Instagram, Linkedin } from "lucide-react";

export default function FooterStatic() {
  // Static contact content - easily editable for GitHub Pages
  const content = {
    address: "123 Creative Street\nDesign City, DC 12345",
    phone: "+1 (555) 123-4567",
    email: "workforgraphixtown@gmail.com"
  };

  const scrollToSection = (selector: string) => {
    const element = document.querySelector(selector);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="bg-[var(--dark-secondary)] py-12 border-t border-gray-800">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-10 h-10 bg-gradient-to-r from-primary to-secondary rounded-lg flex items-center justify-center">
                <Play className="text-white text-lg" />
              </div>
              <span className="text-2xl font-bold">GFX Town</span>
            </div>
            <p className="text-gray-400 mb-6">
              Transforming ideas into stunning visual experiences with professional graphics and video editing services.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 bg-gray-700 hover:bg-primary rounded-lg flex items-center justify-center transition-colors">
                <Facebook className="text-white text-sm" />
              </a>
              <a href="#" className="w-10 h-10 bg-gray-700 hover:bg-primary rounded-lg flex items-center justify-center transition-colors">
                <Twitter className="text-white text-sm" />
              </a>
              <a href="#" className="w-10 h-10 bg-gray-700 hover:bg-primary rounded-lg flex items-center justify-center transition-colors">
                <Instagram className="text-white text-sm" />
              </a>
              <a href="#" className="w-10 h-10 bg-gray-700 hover:bg-primary rounded-lg flex items-center justify-center transition-colors">
                <Linkedin className="text-white text-sm" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-6">Services</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-400 hover:text-primary transition-colors">Graphics Design</a></li>
              <li><a href="#" className="text-gray-400 hover:text-primary transition-colors">Video Editing</a></li>
              <li><a href="#" className="text-gray-400 hover:text-primary transition-colors">Motion Graphics</a></li>
              <li><a href="#" className="text-gray-400 hover:text-primary transition-colors">Brand Identity</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-6">Company</h3>
            <ul className="space-y-3">
              <li>
                <button onClick={() => scrollToSection("#about")} className="text-gray-400 hover:text-primary transition-colors">
                  About Us
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection("#portfolio")} className="text-gray-400 hover:text-primary transition-colors">
                  Portfolio
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection("#contact")} className="text-gray-400 hover:text-primary transition-colors">
                  Contact
                </button>
              </li>
              <li><a href="#" className="text-gray-400 hover:text-primary transition-colors">Careers</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-6">Contact Info</h3>
            <ul className="space-y-3">
              <li className="text-gray-400 whitespace-pre-line">{content.address}</li>
              <li className="text-gray-400">{content.phone}</li>
              <li className="text-gray-400">{content.email}</li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
          <p>&copy; 2024 GFX Town. All rights reserved. | <a href="#" className="hover:text-primary transition-colors">Privacy Policy</a> | <a href="#" className="hover:text-primary transition-colors">Terms of Service</a></p>
        </div>
      </div>
    </footer>
  );
}