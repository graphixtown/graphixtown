import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import AdminControls from "@/components/admin-controls";
import type { PortfolioItem } from "@shared/schema";

export default function PortfolioSection() {
  const [activeFilter, setActiveFilter] = useState("all");
  
  const { data: portfolioItems = [], isLoading } = useQuery<PortfolioItem[]>({
    queryKey: ["/api/portfolio"],
  });

  const categories = [
    { key: "all", label: "All Work" },
    { key: "graphics", label: "Graphics" },
    { key: "video", label: "Video" },
    { key: "motion", label: "Motion" },
  ];

  const filteredItems = activeFilter === "all" 
    ? portfolioItems 
    : portfolioItems.filter(item => item.category === activeFilter);

  if (isLoading) {
    return (
      <section className="py-20 bg-[var(--dark)]">
        <div className="container mx-auto px-6">
          <div className="text-center">Loading portfolio...</div>
        </div>
      </section>
    );
  }

  return (
    <section id="portfolio" className="py-20 bg-[var(--dark)] customizable-section">
      <AdminControls
        actions={[
          { label: "Upload", icon: "upload", action: () => console.log("Upload new work") },
          { label: "Reorder", icon: "move", action: () => console.log("Reorder portfolio items") }
        ]}
      />
      
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Our Portfolio</h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto mb-8">
            Explore our latest projects and see how we've helped businesses transform their visual presence.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category) => (
              <Button
                key={category.key}
                variant={activeFilter === category.key ? "default" : "secondary"}
                className={`px-6 py-2 font-medium transition-colors ${
                  activeFilter === category.key 
                    ? "bg-primary text-white" 
                    : "bg-gray-700 hover:bg-primary text-white"
                }`}
                onClick={() => setActiveFilter(category.key)}
              >
                {category.label}
              </Button>
            ))}
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((item) => (
            <div key={item.id} className="group cursor-pointer">
              <div className="relative overflow-hidden rounded-2xl">
                <img 
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[var(--dark)]/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                    <p className="text-gray-300 text-sm">{item.description}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {filteredItems.length > 6 && (
          <div className="text-center mt-12">
            <Button
              size="lg"
              className="bg-gradient-to-r from-primary to-secondary hover:from-purple-600 hover:to-primary transition-all transform hover:scale-105"
            >
              Load More Projects
            </Button>
          </div>
        )}
      </div>
    </section>
  );
}
