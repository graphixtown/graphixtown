# Overview

This is a full-stack React application for "GFX Town," a creative services company offering graphics design and video editing services. The application features a modern portfolio website with both public-facing content and an admin interface for content management.

The system is built as a single-page application with a Node.js/Express backend, React frontend using TypeScript, and includes comprehensive CRUD operations for managing services, portfolio items, site content, and contact submissions.

# User Preferences

Preferred communication style: Simple, everyday language.
Contact form preference: Direct email links (no backend server required for GitHub Pages hosting).

# System Architecture

## Frontend Architecture
- **React + TypeScript**: Modern React application using TypeScript for type safety
- **Vite**: Build tool and development server for fast development experience
- **Tailwind CSS + shadcn/ui**: Utility-first CSS framework with pre-built component library
- **TanStack Query**: Data fetching and caching library for API state management
- **Wouter**: Lightweight client-side routing library
- **React Hook Form + Zod**: Form handling with schema validation

## Backend Architecture
- **Express.js**: REST API server handling CRUD operations
- **In-Memory Storage**: Currently using a memory-based storage implementation with plans for database integration
- **Type-Safe API**: Shared TypeScript schemas between frontend and backend using Zod validation
- **Session Management**: Prepared for session-based authentication with PostgreSQL session store

## Data Storage
- **Current**: In-memory storage implementation for development
- **Planned**: PostgreSQL database with Drizzle ORM for production
- **Database Schema**: Defined tables for services, portfolio items, site content, and contact submissions
- **Migration Support**: Drizzle-kit configured for database migrations

## API Design
- **RESTful Endpoints**: Conventional REST API structure
- **Resource Management**: 
  - `/api/services` - CRUD operations for service offerings
  - `/api/portfolio` - Portfolio item management with category filtering
  - `/api/content/{section}` - Dynamic site content management
  - `/api/contact` - Contact form submissions and management
- **Data Validation**: Zod schemas ensure consistent data validation across client and server

## Authentication & Authorization
- **Prepared Infrastructure**: Session store configuration ready for implementation
- **Admin Interface**: Dedicated admin routes for content management
- **Security Considerations**: CORS, input validation, and error handling implemented

## Content Management System
- **Dynamic Content**: Site sections (hero, about, contact) are editable through admin interface
- **Media Management**: Image upload and management capabilities planned
- **WYSIWYG Editing**: Admin controls embedded throughout the public site for easy content editing

## Development Features
- **Hot Module Replacement**: Vite provides fast development reloading
- **Type Safety**: End-to-end TypeScript coverage with shared schemas
- **Path Aliases**: Clean import paths using TypeScript path mapping
- **Error Handling**: Comprehensive error boundaries and API error handling

# External Dependencies

## Core Framework Dependencies
- **React Ecosystem**: React 18 with modern hooks and patterns
- **Vite**: Build tool with React plugin for development and production builds
- **Express.js**: Node.js web framework for API server

## UI/UX Libraries
- **Radix UI**: Headless UI primitives for accessibility-compliant components
- **Tailwind CSS**: Utility-first CSS framework with dark theme support
- **Lucide React**: Icon library for consistent iconography
- **shadcn/ui**: Pre-built component library built on Radix UI

## Data Management
- **TanStack Query**: Server state management and caching
- **React Hook Form**: Form state management with performance optimization
- **Zod**: Schema validation for runtime type checking
- **Drizzle ORM**: Type-safe ORM for database operations

## Database & Storage
- **Neon Database**: Serverless PostgreSQL provider (configured)
- **connect-pg-simple**: PostgreSQL session store for Express sessions
- **Drizzle Kit**: Database migration and schema management tool

## Development Tools
- **TypeScript**: Static type checking across the entire stack
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS + Autoprefixer**: CSS processing pipeline
- **Replit Integration**: Development environment optimizations for Replit platform

## Utility Libraries
- **date-fns**: Date manipulation and formatting
- **class-variance-authority**: Utility for creating variant-based component APIs
- **clsx + tailwind-merge**: Conditional CSS class composition
- **nanoid**: URL-safe unique ID generation

The application is designed for easy deployment and scaling, with clear separation between development and production configurations, and prepared infrastructure for database integration and user authentication.