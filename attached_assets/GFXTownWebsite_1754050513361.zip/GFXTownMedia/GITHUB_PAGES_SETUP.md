# GitHub Pages Setup Guide for GFX Town Website

This guide explains how to deploy your GFX Town website to GitHub Pages without needing a backend server.

## 🎯 What's Different for GitHub Pages

The static version includes:
- ✅ **No Backend Required**: All content is stored directly in the code
- ✅ **Contact Form**: Uses EmailJS to send emails directly from the frontend
- ✅ **Easy Content Editing**: All content is in easy-to-edit JavaScript files
- ✅ **Professional Design**: Same beautiful design and animations
- ✅ **Responsive**: Works perfectly on mobile and desktop

## 📁 Files Structure for Static Version

```
client/src/
├── pages/
│   └── home-static.tsx          # Main homepage (no backend needed)
├── components/
│   ├── hero-section-static.tsx     # Hero section with editable content
│   ├── services-section-static.tsx # Services with static data
│   ├── portfolio-section-static.tsx # Portfolio with static data
│   ├── about-section-static.tsx    # About section with static content
│   ├── contact-section-static.tsx  # Contact form with EmailJS
│   └── footer-static.tsx          # Footer with static contact info
```

## 🚀 Quick Deployment Steps

### Step 1: Prepare Your Repository
1. Create a new GitHub repository for your website
2. Copy the `client/` folder contents to your repository
3. Remove server-related files (you only need the frontend)

### Step 2: Update App.tsx
Replace the content in `App.tsx` with:

```tsx
import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import HomeStatic from "@/pages/home-static";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomeStatic} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <TooltipProvider>
      <div className="min-h-screen bg-[var(--dark)] text-white">
        <Toaster />
        <Router />
      </div>
    </TooltipProvider>
  );
}

export default App;
```

### Step 3: Create GitHub Pages Build
1. Add a build script to package.json:
```json
{
  "scripts": {
    "build": "vite build",
    "preview": "vite preview"
  }
}
```

2. Create `.github/workflows/deploy.yml`:
```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - uses: actions/setup-node@v2
      with:
        node-version: '18'
    - run: npm install
    - run: npm run build
    - uses: peaceiris/actions-gh-pages@v3
      with:
        github_token: ${{ secrets.GITHUB_TOKEN }}
        publish_dir: ./dist
```

### Step 4: Configure GitHub Pages
1. Go to your repository settings
2. Navigate to "Pages" section
3. Select "GitHub Actions" as source
4. Your site will be available at `https://username.github.io/repository-name`

## 📧 Email Setup (Direct Email Links - READY TO USE!)

Your contact form is already configured with **direct email links** - the simplest and most reliable option!

### How It Works:
1. Customer fills out the contact form
2. Clicking "Open Email Client" opens their default email app
3. Email is pre-filled with all their information and project details
4. They send the email directly to your business inbox

### What You Get:
- ✅ **Completely free** - no monthly costs
- ✅ **Works everywhere** - on any device with email
- ✅ **No setup required** - ready to use immediately
- ✅ **Professional format** - organized inquiry emails

### Email Address:
All inquiries are sent to: **hello@gfxtown.com**

To change this email address, edit the `mailtoLink` in `contact-section-static.tsx`:
```tsx
const mailtoLink = `mailto:your-business@email.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
```

## ✏️ Content Editing Guide

### Hero Section
Edit `hero-section-static.tsx`:
```tsx
const content = {
  title: "Your Business Name",
  subtitle: "Your business description...",
  backgroundImage: "URL_TO_YOUR_BACKGROUND_IMAGE"
};
```

### Services
Edit `services-section-static.tsx`:
```tsx
const services = [
  {
    title: "Your Service",
    description: "Service description...",
    price: "$299+",
    features: ["Feature 1", "Feature 2", "Feature 3"]
  }
  // Add more services...
];
```

### Portfolio
Edit `portfolio-section-static.tsx`:
```tsx
const portfolioItems = [
  {
    title: "Project Name",
    description: "Project description...",
    category: "graphics", // or "video", "motion"
    imageUrl: "URL_TO_PROJECT_IMAGE"
  }
  // Add more projects...
];
```

### Contact Information
Edit `contact-section-static.tsx` and `footer-static.tsx`:
```tsx
const contactInfo = {
  address: "Your Business Address",
  phone: "Your Phone Number",
  email: "your@email.com"
};
```

## 🎨 Customization Tips

### Colors and Branding
Update `index.css` to change colors:
```css
:root {
  --primary: hsl(252, 89%, 67%);    /* Purple */
  --secondary: hsl(252, 89%, 71%);  /* Light Purple */
  --accent: hsl(43, 96%, 56%);      /* Yellow */
}
```

### Images
- Use high-quality images from Unsplash or your own
- Optimize images for web (use tools like TinyPNG)
- Consider using a CDN for faster loading

### SEO
Add to `index.html`:
```html
<meta name="description" content="GFX Town - Professional graphics design and video editing services">
<meta name="keywords" content="graphics design, video editing, branding, logo design">
<meta property="og:title" content="GFX Town - Creative Visual Solutions">
<meta property="og:description" content="Transform your ideas into stunning visual experiences">
```

## 🔧 Troubleshooting

### Common Issues:
1. **Images not loading**: Check image URLs are accessible
2. **Contact form not working**: Verify EmailJS configuration
3. **Styles not applying**: Check Tailwind CSS build process
4. **Navigation not smooth**: Ensure section IDs match navigation links

### Performance Tips:
1. Optimize images (WebP format recommended)
2. Use image lazy loading
3. Minimize custom CSS
4. Enable compression in GitHub Pages

## 📞 Need Help?

If you need assistance with:
- Setting up EmailJS
- Customizing the design
- Adding new sections
- SEO optimization

Feel free to ask for help with specific modifications!

---

**Your website will be live at:** `https://yourusername.github.io/yourrepository`

This setup gives you a professional business website that:
- ✅ Works perfectly on GitHub Pages
- ✅ Requires no backend server
- ✅ Can receive contact form emails
- ✅ Is easy to customize and maintain
- ✅ Loads fast and looks professional